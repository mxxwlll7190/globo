package com.example.globotest

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
