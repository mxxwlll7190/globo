const String GEMINI_API_KEY = "AIzaSyCsBDcwQNsMZwSh_gTYDjXSn0zISZmhSMo";
